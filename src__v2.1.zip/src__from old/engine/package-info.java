/**
 * Package engine of the TAT.
 *
 * <p>
 * This package give the engine of the TAT.</p>
 *
 * @version 1.0
 * @author Thomas Morin
 */
package engine;
