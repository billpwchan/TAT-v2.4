/**
 * Package scripts of the TAT.
 *
 * <p>
 * This package give the scripts of the TAT.</p>
 *
 * @version 1.0
 * @author Thomas Morin
 */
package script;
